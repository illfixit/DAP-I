public class CharacterSearchTree 
{
    private HuffmanTriple content;
    private CharacterSearchTree leftChild, rightChild;

    public CharacterSearchTree() 
    {
        content = null;
        leftChild = null;
        rightChild = null;
    }

    public HuffmanTriple getContent()
    {
        if ( !isEmpty() )
        {
            return content;
        } else {
            throw new IllegalStateException();
        }
    }

    public boolean isEmpty() 
    {
        return content == null;
    }

    public boolean isLeaf() 
    {
        return !isEmpty() && leftChild.isEmpty() && rightChild.isEmpty();
    }

    public void add( char t )
    {
        if ( isEmpty() ) 
        {
            content = new HuffmanTriple( t );
            leftChild = new CharacterSearchTree();
            rightChild = new CharacterSearchTree();
        }
        else
        {
            if ( content.getToken() > t )
            {
                leftChild.add( t );
            }
            else if ( content.getToken() < t )
            {
                rightChild.add( t );
            }
            else
            {
                content.incrementQuantity();
            }
        }
    }

    public void iterativeAdd( char t )
    {
        CharacterSearchTree current = this;
        while ( !current.isEmpty() && current.content.getToken() != t )
        {
            if ( current.content.getToken() > t )
            {
                current = current.leftChild;
            }
            else
            {
                current = current.rightChild;
            }
        }
        if ( current.isEmpty() ) 
        {
            current.content = new HuffmanTriple( t );
            current.leftChild = new CharacterSearchTree();
            current.rightChild = new CharacterSearchTree();
        }
        else
        {
            current.content.incrementQuantity();
        }
    }

    public String getCode( char t )
    {
        if ( !isEmpty() ) 
        {
            if ( content.getToken() > t )
            {
                return leftChild.getCode( t );
            }
            else if ( content.getToken() < t )
            {
                return rightChild.getCode( t );
            }
            else
            {
                return content.getCode();
            }
        }
        else
        {
            throw new IllegalStateException();
        }
    }

    public int size() 
    {
        if ( isEmpty() ) 
        {
            return 0;
        }
        else
        {
            return 1 + leftChild.size() + rightChild.size();
        }       
    }

    public void show()
    {
        if ( !isEmpty() ) 
        {
            leftChild.show();
            System.out.println( content.toString() );
            rightChild.show();
        }
    }

    public HuffmanTriple[] toArray()
    {
        if ( !isEmpty() ) 
        {
            HuffmanTriple[] collector = new HuffmanTriple[size()];
            toArray( collector, 0 );
            return collector;
        }
        return new HuffmanTriple[0];
    }

    private int toArray( HuffmanTriple[] collector, int index ) 
    {
        if ( !isEmpty() )
        {
            index = leftChild.toArray( collector, index );
            collector[index] = content;
            index = rightChild.toArray( collector, index + 1 );
        }
        return index;
    }

    // Uebungsblatt 8 - Loesungen

    // 8.3 Loeschen eines Knotens

    private CharacterSearchTree biggestInLeft()
    {
        CharacterSearchTree current = leftChild;
        if ( ! current.isEmpty() ) 
        {
            while ( ! current.rightChild.isEmpty() ) 
            {
                current = current.rightChild;
            }
        }
        return current;
    }

    public void delete() 
    {
        CharacterSearchTree biggest = biggestInLeft();
        if ( ! biggest.isEmpty() )
        {
            content = biggest.content;
            biggest.content = biggest.leftChild.content;
            biggest.rightChild = biggest.leftChild.rightChild;
            biggest.leftChild = biggest.leftChild.leftChild;
        } else {
            content = rightChild.content;
            leftChild = rightChild.leftChild;
            rightChild = rightChild.rightChild;
        }
    }

    // 8.4 completePath

    public boolean completePath()
    {
        if ( isEmpty() || isLeaf() ) 
        {
            return true;
        } else {
            if ( leftChild.isEmpty() || rightChild.isEmpty() )
            {
                return false;
            }
            else
            {
                return leftChild.completePath() || rightChild.completePath();
            }
        }
    }

}
