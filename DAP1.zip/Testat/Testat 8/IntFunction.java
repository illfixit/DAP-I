public interface IntFunction
{
    int apply( int k, int v );
}
