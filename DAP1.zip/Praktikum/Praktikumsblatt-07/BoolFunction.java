public interface BoolFunction
{
    boolean apply( int p1, int p2 );
}
