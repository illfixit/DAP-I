public interface IntFunction
{
    int apply( int p1, int p2 );
}
