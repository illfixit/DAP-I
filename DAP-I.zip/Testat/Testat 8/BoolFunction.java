public interface BoolFunction
{
    boolean apply( int k, int v );
}

