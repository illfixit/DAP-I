import java.util.Arrays;

public class VorTestat1 {
    public static void main(String[] args) {

        // System.out.println("isSorted([1,2,3]): " + isSorted(new int[] { 1, 2, 3 }));
        // System.out.println("isSorted([3,2,1]): " + isSorted(new int[] { 3, 2, 1 }));
        // try {
        // System.out.println("isSorted([]): " + isSorted(new int[] {}));
        // } catch (Exception e) {
        // System.out.println(e);
        // }
        // System.out.println("isSorted([1]): " + isSorted(new int[] { 1 }));
        // System.out.println("isSorted([1,2]): " + isSorted(new int[] { 1, 2 }));

        // System.out.println("checkArray([1,2,3,2,1]): " + checkArray(new int[] { 1, 2,
        // 3, 2, 1 }));
        // System.out.println("checkArray([1,2,3,3,2,1]): " + checkArray(new int[] { 1,
        // 2, 3, 3, 2, 1 }));

        // System.out.println("checkArray([1,2,3,4,5,6]): " + checkArray(new int[] { 1,
        // 2, 3, 4, 5, 6 }));
        // System.out.println("checkArray([1,1]): " + checkArray(new int[] { 1, 1 }));

        // System.out.println("checkArray([1]): " + checkArray(new int[] { 1 }));

        // System.out.println("checkArray([]): " + checkArray(new int[] {}));

        // System.out.println("increaseArray(new int[80,7,1,56,11,72,43,37], 17): "
        // + Arrays.toString(increaseArray(new int[] { 80, 7, 1, 56, 11, 72, 43, 37 },
        // 17)));

        // System.out.println("doubleIfContainsPositive([0,-7,1,5,-1,2,4]): "
        // + Arrays.toString(doubleIfContainsPositive(new int[] { 0, -7, 1, 5, -1, 2, 4
        // })));

        // System.out.println("doubleIfContainsPositive([0,-7,-1,-5,-1,-2,-4]): "
        // + Arrays.toString(doubleIfContainsPositive(new int[] { 0, -7, -1, -5, -1, -2,
        // -4 })));

        // System.out.println("toString([0,-7,1,5,-1,2,4]): "
        // + toString(new int[] { 0, -7, 1, 5, -1, 2, 4 }));

        // System.out.println("toString([0,-7,-1,-5,-1,-2,-4]): "
        // + toString(new int[] { 0, -7, -1, -5, -1, -2, -4 }));

        // System.out.println("copyStartingValues([80,7,1,56,11,72,43]): "
        // + Arrays.toString(copyStartingValues(new int[] { 80, 7, 1, 56, 11, 72, 43
        // })));

        // System.out.println("selectNegatives(new int[]{80,-7,1,56,-11,-72,0,37}): "
        // + Arrays.toString(selectNegatives(new int[] { 80, -7, 1, 56, -11, -72, 0, 37
        // })));

        // System.out.println("copyAndInvert([80,-7,1,56,-11,-72,0,37]): "
        // + Arrays.toString(copyAndInvert(new int[] { 80, -7, 1, 56, -11, -72, 0, 37
        // })));

        // System.out.println(" addArrays([80,-7,1,56,-11,-72,0,37],[80, 7, 1, 56, 11,
        // 72, 43, 37]): "
        // + Arrays.toString(addArrays(new int[] { 80, -7, 1, 56, -11, -72, 0, 37
        // }, new int[] { 80, 7, 1, 56, 11, 72, 43, 37
        // })));

        // System.out.println(
        // "countSequences(int[0,1,2,3,0,1,2,3]): " + countSequences(new int[] { 0, 1,
        // 2, 3, 0, 1, 2, 3 }));
        // System.out.println(
        // "countSequences(int[0,1,2,3,0,0,1,2,3]): " + countSequences(new int[] { 0, 1,
        // 2, 3, 0, 0, 1, 2, 3 }));
        // System.out.println(
        // "countSequences(int[0,1,2,3,0,1,2,3,0]): " + countSequences(new int[] { 0, 1,
        // 2, 3, 0, 1, 2, 3, 0 }));
        // System.out.println(
        // "countSequences(int[0,1,2,3,0]): " + countSequences(new int[] { 0, 1, 2, 3, 0
        // }));
        // System.out.println(
        // "countSequences(int[0,1,2,3,0,0,1]): " + countSequences(new int[] { 0, 1, 2,
        // 3, 0, 0, 1 }));
        // System.out.println(
        // "countSequences(int[0,0,1]): " + countSequences(new int[] { 0, 0, 1 }));
        // System.out.println(
        // "countSequences(int[0,0,0]): " + countSequences(new int[] { 0, 0, 0 }));
        // System.out.println(
        // "countSequences(int[1,0,0]): " + countSequences(new int[] { 1, 0, 0 }));

        // System.out.println(
        // "twoTimes([2, 3, 4, 3, 7, 7, 4, 1, 2, 1]): " + twoTimes(new int[] { 2, 3, 4,
        // 3, 7, 7, 4, 1, 2, 1 }));
        // System.out.println(
        // "twoTimes([2, 2, 8, 8, 5, 5, 3, 3, 9, 9]): " + twoTimes(new int[] { 2, 2, 8,
        // 8, 5, 5, 3, 3, 9, 9 }));
        // System.out.println(
        // "twoTimes([2, 3, 2, 3, 5, 5, 1, 2, 1, 2]): " + twoTimes(new int[] { 2, 3, 2,
        // 3, 5, 5, 1, 2, 1, 2 }));
        // System.out
        // .println("twoTimes([2, 3, 3, 5, 5, 4, 1, 2, 1]): " + twoTimes(new int[] { 2,
        // 3, 3, 5, 5, 4, 1, 2, 1 }));

    }

    // 1 - Werte zählen
    // Schreibe die Methode int countNegatives( int[] arr ),
    // die als Parameter ein Feld besitzt. Die Methode
    // countNegatives zählt die negativen Werte in diesem Feld
    // und gibt den ermittelten Wert zurück.
    public static int countNegatives(int[] arr) {
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < 0) {
                count++;
            }
        }
        return count;
    }

    // 2 - Werte aufsummieren
    // Schreibe die Methode int sumUpNegatives( int[] arr ),
    // die als Parameter ein Feld besitzt.
    // Die Methode sumUpNegatives bildet die Summe der negativen
    // Werte in diesem Feld und gibt den ermittelten Wert zurück.
    public static int sumUpNegatives(int[] arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < 0) {
                sum += arr[i];
            }
        }
        return sum;
    }

    // 3 - Bestimmen des Maximums in einem Feld
    // Schreibe die Methode int maximum( int[] arr ), die ein
    // Feld als Parameter besitzt und die den größten Wert in diesem
    // Feld bestimmt und zurückgibt.
    //
    // Hinweis: Versuche, mit einem Durchlauf durch das Feld auszukommen.
    public static int maximum(int[] arr) {
        int max = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        return max;

    }

    // 4 - Bestimmen der Häufigkeit des Maximums in einem Feld
    // Schreibe die Methode int countMaximum( int[] arr ),
    // die ein Feld von int-Werten als Parameter besitzt und
    // die zählt, wie häufig der größte Wert vorkommt.
    // Die ermittelte Anzahl wird zurückgegeben.
    public static int countMaximum(int[] arr) {

        // Falls wir "maximum" Funktion benutzen dürfen
        // int max = maximum(arr);

        // Sonst

        int max = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }

        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == max) {
                count++;
            }
        }
        return count;

    }

    // 5 - Sortierung prüfen
    // Schreibe die Methode boolean isSorted( int[] arr ),
    // die als Parameter ein Feld besitzt. Die Methode isSorted soll
    // true zurückgeben, falls die im Feld enthaltenen Werte
    // aufsteigend sortiert sind; sonst wird false zurückgegeben.
    public static boolean isSorted(int[] arr) {
        if (arr.length >= 1) {

            for (int i = 1; i < arr.length; i++) {
                if (arr[i] < arr[i - 1]) {
                    return false;
                }
            }
            return true;
        } else {
            throw new IllegalArgumentException();
        }
    }

    // 6 - Palindrome erkennen
    // Ein Palindrom ist eine Folge von int-Werten, die vorwärts
    // und rückwärts gelesen die identische Ziffernfolge ergibt.
    //
    // Beispiele: Die Folgen 12 34 78 34 12 oder
    // 5 17 88 88 17 5 sind Palindrome.
    //
    // Schreibe die Methode boolean checkArray( int[] arr ),
    // die für das als Parameter übergebene Feld bestimmt, ob die
    // Folge der Zahlen ein Palindrom bildet. Die Methode
    // gibt einen Wert des Typs boolean zurück.
    public static boolean checkArray(int[] arr) {

        if (arr.length < 1) {
            throw new IllegalArgumentException();
        }

        for (int i = 0; i < arr.length / 2; i++) {
            if (arr[i] != arr[arr.length - i - 1]) {
                return false;
            }
        }
        return true;
    }

    // 7 - Erhöhen der Inhalte eines Feldes
    // Schreibe die Methode int[] increaseArray( int[] arr, int z ),
    // die als Parameter ein Feld und einen int-Wert z besitzt.
    // Die Methode increaseArray erhöht alle Werte des Feldes
    // um den Wert z und gibt das veränderte Feld zurück.
    //
    // Beispiel: Werden ein Feld mit den Elementen
    // 80,7,1,56,11,72,43,37 als erstes und der Wert 17
    // als zweites Argument übergeben, so wird dieses Feld
    // verändert und als 97,24,18,73,28,89,60,54 zurückgegeben.
    public static int[] increaseArray(int[] arr, int z) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = arr[i] + z;
        }

        return arr;
    }

    // 8 - Bedingtes Verdoppeln der Inhalte eines Feldes
    // Schreibe die Methode
    // int[] doubleIfContainsPositive( int[] arr ),
    // die als Parameter ein Feld des Typs int besitzt.
    // Die Methode doubleIfContainsPositive verdoppelt alle
    // Werte des Feldes, falls in dem Feld mindestens ein
    // positiver Wert vorkommt; sonst bleibt das Feld unverändert.
    // Das (veränderte) Feld soll zurückgegeben werden.
    // Beispiel: Wird ein Feld mit den Elementen
    // 0,-7,1,5,-1,2,4 als Argument übergeben,
    // so wird dieses Feld verändet und als
    // 0,-14,2,10,-2,4,8 zurückgegeben.
    public static int[] doubleIfContainsPositive(int[] arr) {

        boolean containsPositive = false;
        int[] tempArr = new int[arr.length];

        for (int i = 0; i < arr.length; i++) {
            tempArr[i] = arr[i] * 2;
            if (!containsPositive & arr[i] > 0) {
                containsPositive = true;
            }
        }

        if (containsPositive) {
            return tempArr;
        } else {
            return arr;
        }
    }

    // 9 - Erzeugen eines Textes
    // Schreibe die Methode String toString( int[] arr ),
    // die als Parameter ein Feld besitzt. Die Methode toString
    // erzeugt einen Text, der alle Inhalte des Feldes in der
    // Reihenfolge ihres Auftretens durch Kommas getrennt enthält.
    // Der erzeugte Text wird zurückgegeben.
    public static String toString(int[] arr) {
        String result = "";
        for (int i = 0; i < arr.length; i++) {
            if (i != arr.length - 1) {
                result += arr[i] + ",";
            } else {
                result += arr[i];
            }
        }

        return result;
    }

    // 10 - Erzeugen eines Feldes mit drei Elementen
    // Schreibe die Methode int[] copyStartingValues( int[] arr ),
    // die als Parameter ein Feld besitzt. Die Methode
    // copyStartingValues erzeugt ein neues Feld, das in seinen
    // Elementen genau die ersten drei Werte des als Argument
    // übergebenen Feldes enthält, falls dieses mehr als zwei
    // Elemente besitzt. Das erzeugte Feld wird zurückgegeben.
    // Besitzt das als Argument übergebene Feld weniger als drei
    // Elemente, wird es vollständig kopiert.
    //
    // Beispiel: Wird ein Feld mit den Elementen
    // 80,7,1,56,11,72,43,37 als Argument übergeben,
    // so wird ein neues Feld mit den Werten 80,7,1 zurückgegeben.
    public static int[] copyStartingValues(int[] arr) {
        if (arr.length < 3) {
            throw new IllegalArgumentException();
        }

        int[] result = new int[3];

        for (int i = 0; i < 3; i++) {
            result[i] = arr[i];
        }

        // Alternative, need to import java.util.Arrays;
        // result = Arrays.copyOfRange(arr, 0, 3);

        return result;
    }

    // 11 - Erzeugen eines Feldes mit ausgesuchten Inhalten
    // Schreibe die Methode int[] selectNegatives( int[] arr ),
    // die als Parameter ein Feld besitzt. Die Methode selectNegatives
    // gibt ein Feld zurück, in dem ausschließlich die negativen Werte
    // des als Argument übergebenen Feldes enthalten sind.
    // Die Methode countNegatives kann dazu benutzt werden,
    // die Größe des zurückgegebenen Feldes zu bestimmen.
    //
    // Beispiel: Wird ein Feld mit den Elementen
    // 80,-7,1,56,-11,-72,0,37 als Argument übergeben,
    // so wird ein neues Feld mit den Werten -7,-11,-72 zurückgegeben.
    public static int[] selectNegatives(int[] arr) {
        int[] result = new int[countNegatives(arr)];
        int resultIdx = 0;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < 0) {
                result[resultIdx] = arr[i];
                resultIdx++;
            }
        }

        return result;

    }

    // 12 - Erzeugen eines Feldes mit invertiertem Inhalt
    // Schreibe die Methode int[] copyAndInvert( int[] arr ),
    // die als Parameter ein Feld besitzt. Die Methode
    // copyAndInvert gibt ein Feld zurück, das die Werte des als
    // Argument übergebenen Feldes in umgekehrter Reihenfolge enthält.
    //
    // Beispiel: Wird ein Feld mit den Elementen
    // 80,-7,1,56,-11,-72,0,37 als Argument übergeben, so wird ein
    // neues Feld mit den Werten 37,0,-72,-11,56,1,-7,80 zurückgegeben.
    public static int[] copyAndInvert(int[] arr) {
        int[] result = new int[arr.length];

        for (int i = 0; i < arr.length; i++) {
            result[arr.length - i - 1] = arr[i];
        }

        return result;
    }

    // 13 - Zusammenführen von Feldern
    // Schreibe die Methode int[] addArrays( int[] arr1, int[] arr2 ),
    // die zwei int-Felder als Parameter besitzt.
    // Haben diese Felder die gleiche Länge, so werden die Werte am
    // gleichen Index aus beiden Feldern addiert und die Summe unter
    // diesem Index in einem dritten int-Feld abgelegt werden.
    // Dieses Feld wird als Ergebnis des Aufrufs von addArrays
    // zurückgegeben. Unterscheiden sich die als Argumente übergebene
    // Felder in ihrer Länge, wird ein leeres Feld zurückgegeben.
    public static int[] addArrays(int[] arr1, int[] arr2) {
        if (arr1.length == arr2.length) {
            int[] result = new int[arr1.length];

            for (int i = 0; i < arr1.length; i++) {
                result[i] = arr1[i] + arr2[i];
            }

            return result;

        } else {
            return new int[] {};
        }
    }

    // 14 - Zählen von Folgen
    // Schreibe die Methode int countSequences( int[] arr ),
    // die ein Feld als Parameter besitzt. Die Methode
    // countSequences ermittelt die Anzahl der im Feld enthaltenen
    // Zahlenfolgen, in denen nicht der Wert 0 vorkommt. Eine
    // solche Zahlenfolge endet immer mit dem Auftreten einer 0
    // oder dem Ende des Feldes. Die ermittelte Anzahl wird von der
    // Methode zurückgegeben.
    //
    // Beispiel: Wird ein Feld mit den Elementen
    // 80,7,1,0,11,72,0,0,37,61 als Argument übergeben,
    // so wird der Aufruf von countSequences als Ergebnis
    // 3 liefern, da die Folgen 80,7,1 und 11,72 und 37,61 auftreten.
    public static int countSequences(int[] arr) {
        int count = 0;
        int nonZeroCount = 0;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == 0) {
                if (nonZeroCount != 0) {
                    count++;
                    nonZeroCount = 0;
                }
            } else {
                nonZeroCount++;
                if (i == arr.length - 1 && nonZeroCount != 0) {
                    count++;
                }
            }
        }

        return count;
    }

    // 15 - Analyse eines Felds
    // Schreibe die Methode boolean twoTimes( int[] arr ),
    // die true zurückgibt, wenn das Feld arr mindestens zwei
    // Elemente besitzt und jeder im Feld vorkommende Wert
    // genau zweimal auftritt. Sonst wird false zurückgegeben.
    //
    // Beispiele: Feld Ergebnis
    // 2 3 4 3 7 7 4 1 2 1 true
    // 2 2 8 8 5 5 3 3 9 9 true
    // 2 3 2 3 5 5 1 2 1 2 false, da der Wert 2 zu häufig vorkommt
    // 2 3 3 5 5 4 1 2 1 false, da der Wert 4 nur einmal vorkommt
    public static boolean twoTimes(int[] arr) {
        if (arr.length % 2 != 0 || arr.length < 4) {
            return false;
        }

        for (int i = 0; i < arr.length; i++) {
            int times = 0;
            for (int k = 0; k < arr.length; k++) {
                if (arr[i] == arr[k]) {
                    times++;
                }
            }
            if (times != 2) {
                return false;
            }
        }

        return true;
    }

}
